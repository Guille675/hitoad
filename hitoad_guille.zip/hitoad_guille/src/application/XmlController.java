package application;

import java.io.File;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class XmlController {

	public TextArea mostxml;

	public void mostrarxml() {
		StaXParser read = new StaXParser();
		List<Item> readConfig = read.readConfig("prueba.xml");
		for (Item item : readConfig) {
			mostxml.setText(item.toString());
		}
	}

	public TextField nom;
	public TextField apellidos;
	

	public void escribirxml() {
		try {

			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			// Elemento ra�z
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("config");
			doc.appendChild(rootElement);

			Node nodoraiz = doc.getDocumentElement();

			Element root2 = doc.createElement("item");
			rootElement.appendChild(root2);

			/****************************************************/

			if (nom.getText().equals("")) {
				Element nombre = doc.createElement("nombre");
				System.out.println("Campos vacios");
				nombre.setTextContent("Vacio");

			} else {
				Element nombre = doc.createElement("nombre");
				nombre.setTextContent(nom.getText());
				root2.appendChild(nombre);
			}

			if (apellidos.getText().equals("")) {
				Element ciudad = doc.createElement("apellidos");
				System.out.println("Campos vacios");
				ciudad.setTextContent("Vacio");

			} else {
				Element ciudad = doc.createElement("apellidos");
				ciudad.setTextContent(apellidos.getText());
				root2.appendChild(ciudad);
			}

			
				nodoraiz.appendChild(root2);
			
			/****************************************************/

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("prueba.xml"));
			transformer.transform(source, result);
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		}

		nom.setText("");
		apellidos.setText("");
		

	}

}
